<?php

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HeroController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\WorkController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\MissionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\ContactUsController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Auth\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();
Route::get('/admin', [LoginController::class, 'showLoginForm']);

Route::get('/', HomeController::class)->name('home');
Route::get('/services/{service}', [ServiceController::class, 'show'])->name('service.show');
Route::get('/projects/{project}', [ProjectController::class , 'show'])->name('project.show');
Route::get('/heros/{hero}',[HeroController::class,'show'])->name('hero.show');
Route::resource('/contact', ContactUsController::class)->only('store');
Route::get('/about-us', [AboutController::class, 'show'])->name('about-us');

Route::get('/contact-us', function () {
	return view('contact-us');
})->name('contact-us');

Route::get('/portfolio', function () {
	return view('portfolio');
})->name('portfolio');


Route::middleware(['auth'])->group(function () {
	Route::get('/dashboard', DashboardController::class)->name('dashboard');
	Route::resource('/profile', ProfileController::class,)->only('show', 'update');
	Route::resource('/service', ServiceController::class)->except('show');
	Route::resource('/project', ProjectController::class)->except('show');
	Route::resource('/about', AboutController::class);
	Route::resource('/hero', HeroController::class)->except('show');
	Route::resource('/work', WorkController::class)->except('show');
	Route::resource('/contact', ContactUsController::class)->except('store', 'create', 'update');
	Route::resource('/team', TeamController::class)->except('show');
	Route::resource('/client', ClientController::class)->except('show');
	Route::resource('/mission', MissionController::class)->except('show');

	Route::get('/users', function () {
		$users = User::latest()->get();
		return view('auth.users', compact('users'));
	})->name('users');

	Route::delete('/user/{user}', function ($user) {
		User::findOrFail($user)->delete();
		return redirect()->back()->with('message', 'Data Deleted.');
	})->name('user.destroy');
});
